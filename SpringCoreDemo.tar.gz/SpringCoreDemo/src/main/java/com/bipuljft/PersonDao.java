package com.bipuljft;

import java.util.List;

/**
 * Created by bipul on 4/5/17.
 */
public interface PersonDao {
    public void save(Person p);

    public List<Person> list();
}
