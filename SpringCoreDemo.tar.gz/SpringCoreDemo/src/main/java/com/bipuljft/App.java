package com.bipuljft;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import java.util.List;

public class App
{
    public static void main( String[] args)
    {
//        ApplicationContext applicationContext = new FileSystemXmlApplicationContext("src/main/resources/xmlfile/bean.xml");
//        Person person = (Person) applicationContext.getBean("person");

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");

        PersonDao personDAO = context.getBean(PersonDao.class);

        EmployeeDao employeeDao = context.getBean(EmployeeDao.class);

//        ApplicationContext context = new FileSystemXmlApplicationContext("src/main/resources/xmlfile/bean.xml");

//        PersonDao personDAO = context.getBean(PersonDao.class);

        Person person = new Person();
        person.setName("Def");
        person.setCountry("India");

        personDAO.save(person);

        Employee employee = new Employee();
        employee.setName("BipulD");
        employee.setAge(24);
        employee.setAddress("jft ghaziabad");

        Employee employee1 = new Employee();
        employee1.setName("BipulE");
        employee1.setAge(14);
        employee1.setAddress("jft vijaynagar");
        employeeDao.save(employee);
        employeeDao.save(employee1);

        System.out.println("Employee saved");
        List<Person> list = personDAO.list();

        for(Person p : list){
            System.out.println("Person List::"+p.getName());
        }
        //close resources

    }
}
