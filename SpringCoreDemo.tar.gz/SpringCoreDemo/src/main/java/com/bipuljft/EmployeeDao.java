package com.bipuljft;
import java.util.List;
/**
 * Created by bipul on 4/5/17.
 */
public interface EmployeeDao {
    public void save(Employee employee);
    public List<Employee> list();
}
